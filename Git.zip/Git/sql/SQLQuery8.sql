select * from employee1 e
join city c
on c.city_id = e.employee1_city
join state s
on s.state_id = c.state


select * from employee1 where state.state_id = 1
select * from city

select state_name from state where state_id in (1,2)