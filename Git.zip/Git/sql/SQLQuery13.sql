select * from sales.SalesOrderHeader where datepart(yy,OrderDate) in (2012,2013)
select * from INFORMATION_SCHEMA.COLUMNS
select * from sales.SalesOrderDetail
select * from Production.ProductCategory
select * from Production.ProductSubcategory
select * from Production.Product


select pp.Name, pp1.Name from Production.ProductCategory pp
join
Production.ProductSubcategory pp1 
on pp.ProductCategoryID = pp1.ProductCategoryID


select DATEPART(YYYY, soh.Duedate) as [calendar year], st.[Group] as [Sales Territory Group],
cr.Name as [Sales Territory Country], cr.Name as [Sales Territory Region],
SUM(soh.TotalDue) as [Sales Amount]
from Sales.SalesOrderHeader as soh
join Sales.SalesTerritory as st on soh.TerritoryID = st.TerritoryID
join Sales.SalesOrderDetail as sod on sod.SalesOrderID = sod.SalesOrderID
join Production.ProductCostHistory as pch on sod.ProductID = pch.ProductID
join Person.CountryRegion as cr on st.CountryRegionCode = cr.CountryRegionCode
group by DATEPART(YYYY, soh.DueDate), st.[Group], cr.Name
order by [calendar year]





select datepart(YYYY, soh.DueDate) as [Calendar Year], st.[Group] as [Sales Territory Group],
sum(soh.TotalDue) as [Sales Amount], pc.Name as Category
from Sales.SalesOrderHeader as soh
inner join Sales.SalesTerritory as st on soh.TerritoryID=st.TerritoryID
inner join Sales.SalesOrderDetail as sod on soh.SalesOrderID= sod.SalesOrderID
inner join Production.ProductCostHistory as pch on sod.ProductID=pch.ProductID
cross join Production.ProductCategory as pc
group by DATEPART(yyyy,soh.DueDate),st.[Group],pc.Name
order by [Calendar Year]

SELECT PC.Name AS ProdCat, PS.Name AS SubCat, DATEPART(yy,SH.OrderDate) AS OrderYear,
'Q' + DATENAME(qq, SH.OrderDate) AS OrderQtr,DATENAME(mm, SH.OrderDate) AS OrderMonth,
ST.Name as Country,
SUM(SO.UnitPrice * SO.OrderQty) AS Sales FROM PRODUCTION.ProductSubCategory 
PS INNER JOIN SALES.SalesOrderHeader SH INNER JOIN SALES.SalesOrderDetail SO 
ON SH.SalesOrderID =SO.SalesOrderID INNER JOIN SALES.SalesTerritory ST
ON SH.TerritoryID =ST.TerritoryID INNER JOIN PRODUCTION.Product P 
ON SO.ProductID = P.ProductID ON PS.ProductSubCategoryID = P.ProductSubCategoryID INNER JOIN PRODUCTION.ProductCategory 
PC ON PS.ProductCategoryID = PC.ProductCategoryID WHERE
(SH.OrderDate BETWEEN '1/1/12' AND '12/31/13')GROUP BY DATEPART(yy, SH.OrderDate),
PC.Name, PS.Name, 'Q' + DATENAME(qq,SH.OrderDate), DATENAME(mm, SH.OrderDate),
ST.Name,PS.ProductSubCategoryID



SELECT PC.Name AS ProdCat, PS.Name AS SubCat, DATEPART(yy,SH.OrderDate) AS OrderYear,
'Q' + DATENAME(qq, SH.OrderDate) AS OrderQtr,
SUM(SO.UnitPrice * SO.OrderQty) AS Sales FROM PRODUCTION.ProductSubCategory 
PS INNER JOIN SALES.SalesOrderHeader SH INNER JOIN SALES.SalesOrderDetail SO 
ON SH.SalesOrderID =SO.SalesOrderID INNER JOIN PRODUCTION.Product P 
ON SO.ProductID = P.ProductID ON PS.ProductSubCategoryID = P.ProductSubCategoryID 
INNER JOIN PRODUCTION.ProductCategory 
PC ON PS.ProductCategoryID = PC.ProductCategoryID WHERE
(SH.OrderDate BETWEEN '1/1/12' AND '12/31/13')GROUP BY DATEPART(yy, SH.OrderDate),
PC.Name, PS.Name, 'Q' + DATENAME(qq,SH.OrderDate), DATENAME(mm, SH.OrderDate),PS.ProductSubCategoryID

