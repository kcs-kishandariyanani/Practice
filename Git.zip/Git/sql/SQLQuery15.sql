

select * from sales.SalesOrderHeader
select * from sales.SalesOrderDetail




use AdventureWorks2014
select year(soh.DueDate) [Year], (sod.[ProductID]),
sum(sod.OrderQty) [TotalOrderQty]
from Sales.SalesOrderHeader soh
join Sales.SalesOrderDetail sod
on soh.SalesOrderID = sod.SalesOrderID
group by (sod.OrderQty), (soh.DueDate), sod.[ProductID]
order by (sod.OrderQty), (soh.DueDate), sod.[ProductID]

use [Kishan.Dariyanani]
create table Product2014(
  id int constraint PK_Product2014_ID primary key identity(1,1),
  ProductYear int,
  ProductID int,
  TotalOrderQty int
)
select * from Product2011
select * from Product2012
select * from Product2013
select * from Product2014


SELECT YEAR(soh.DueDate) AS Year, sod.ProductID, SUM(sod.OrderQty) AS TotalOrderQty
FROM     Sales.SalesOrderHeader AS soh INNER JOIN
                  Sales.SalesOrderDetail AS sod ON soh.SalesOrderID = sod.SalesOrderID
GROUP BY soh.DueDate, sod.ProductID
ORDER BY soh.DueDate, sod.ProductID
