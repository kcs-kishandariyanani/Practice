create table tmp(
	id int,
	name varchar(20)
)
select * from [Kishan.Dariyanani].dbo.tmp

create schema abc

create table abc.tmp(
	id int,
	name varchar(20)
)

alter table tmp add mob numeric(10)
alter table tmp alter column name varchar(100)
select * from tmp


alter table tmp drop column mob

insert into tmp values(2,'Ajay'),(3,'Prashant')

insert into tmp (name,id) values('Kishan',5)

update tmp set name='Kishan' where id=2

delete from tmp where id=5

create table emp(
	e_id int primary key identity(1,1),
	name varchar(20) not null,
	gender varchar(10),
	email varchar(100) unique,
	salary numeric(5) check(salary>10000)

)
select * from emp

insert into emp values('Kishan','Male','Kishan@gmail.com',12000)

alter table emp drop constraint [CK_emp_gender]

alter table emp add constraint CK_emp_gender check (gender = 'male' or gender = 'female')

insert into emp values('Ajay','MaLe','ajay@gmail.com',15000)

insert into emp values('Ajay','MaLe','ajay1@gmail.com',15000)

insert into emp values('Kishan','Male','kishan1@gmail.com',1000)

