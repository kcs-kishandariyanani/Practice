use AdventureWorks2014
select distinct [Group] from sales.SalesTerritory
select distinct 


select distinct Name from Person.CountryRegion
select * from sales.SalesOrderHeader

select distinct DATEPART(YYYY, soh.DueDate) from Sales.SalesOrderHeader as soh

group by DATEPART(YYYY, soh.DueDate), st.[Group], cr.Name
order by [calendar year]
SELECT DISTINCT p.Name
FROM Person.CountryRegion AS p INNER JOIN
Sales.SalesTerritory AS s ON p.CountryRegionCode = s.CountryRegionCode
WHERE (s.[Group] IN ('Europe'))
