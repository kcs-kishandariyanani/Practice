select * from abt


drop table abt1

select * into abt1 from abt where id <5
select * from abt1
select * from abt
select * into sales from AdventureWorks2014.Sales.SalesOrderDetail
select * from sales
select * from AdventureWorks2014.Sales.SalesOrderDetail

update sales set ModifiedDate = '2012' 

declare @maxid int = (select MAX(SalesOrderID) from sales)
print @maxid
update sales
set ModifiedDate =  DATEADD(yy,10,ModifiedDate) where YEAR(ModifiedDate) = 2012



ROW_NUMBER() over (order by SalesOrderID) + @maxid SalesOrderID from sales
where YEAR(ModifiedDate) = 2011)
select * from sales