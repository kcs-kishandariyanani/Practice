SELECT PC.Name AS ProdCat, PS.Name AS SubCat, DATEPART(yy,SH.OrderDate) AS OrderYear,
'Q' + DATENAME(qq, SH.OrderDate) AS OrderQtr,DATENAME(mm, SH.OrderDate) AS OrderMonth,
ST.Name as Country,
SUM(SO.UnitPrice * SO.OrderQty) AS Sales FROM PRODUCTION.ProductSubCategory 
PS INNER JOIN SALES.SalesOrderHeader SH INNER JOIN SALES.SalesOrderDetail SO 
ON SH.SalesOrderID =SO.SalesOrderID INNER JOIN SALES.SalesTerritory ST
ON SH.TerritoryID =ST.TerritoryID INNER JOIN PRODUCTION.Product P 
ON SO.ProductID = P.ProductID ON PS.ProductSubCategoryID = P.ProductSubCategoryID INNER JOIN PRODUCTION.ProductCategory 
PC ON PS.ProductCategoryID = PC.ProductCategoryID WHERE
(SH.OrderDate BETWEEN '1/1/12' AND '12/31/13')GROUP BY DATEPART(yy, SH.OrderDate),
PC.Name, PS.Name, 'Q' + DATENAME(qq,SH.OrderDate), DATENAME(mm, SH.OrderDate),
ST.Name,PS.ProductSubCategoryID

select * from SALES.SalesOrderHeader SH where SH.OrderDate BETWEEN '1/1/12' AND '12/31/13'