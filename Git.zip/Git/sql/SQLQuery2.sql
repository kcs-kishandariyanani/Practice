create table department(
	d_id int primary key identity(1,1),
	d_name varchar(20) not null
)

select * from sys.tables
select * from INFORMATION_SCHEMA.TABLES


select * from sys.all_columns
select * from INFORMATION_SCHEMA.COLUMNS

create table employee(
	e_id int primary key identity(1,1),
	e_name varchar(20) not null,
	e_mail varchar(100) unique,
	e_salary numeric constraint CK_emp_salary check(e_salary>10000),
	e_dob date,
	e_mob numeric(10),
	e_state varchar(10) default 'Gujarat',
	department_id int foreign key references department(d_id) 
)

select * from employee

insert into department values('it'),('sales'),('finance'),('hr')

select * from department

insert into employee values('Kishan','Kishan1@gmail.com',12000,'03/10/2022',9574486815,'gujarat',1),
('Ajay','Ajay@gmail.com',15000,'03/10/2022',9574486816,'gujarat',2),
('abc','abc@gmail.com',12000,'03/10/2022',9574486815,'gujarat',4)


set identity_insert employee on
insert into employee (e_id,e_name,e_mail,e_salary,e_dob,e_mob,e_state,department_id) values(100,'xyz','xyz@gmail.com',12000,'03/10/2022',9574486825,'gujarat',1)
set identity_insert employee off
select * from employee

insert into employee values('xyz','xyz@gmail.com',12000,'03/10/2022',9574486825,'gujarat',1)
