insert into emp values('kdm','female','kdm@gmail.com',10000)
select * from emp


select *from emp where gender='male'

select * from (select *,DENSE_RANK() over (order by salary desc) sal from emp where gender='male') a where sal=1


select max(salary) from emp group by gender
select * from emp

select *  into col from emp where salary is null
select top 0 * from emp
EXEC sp_columns 'emp'
select * from emp where salary is null
select * from col
select gender='male'& max (salary) from emp

create table stock(
	id int primary key identity(1,1),
	p_name varchar(20),
	quantity int 
)
insert 
create 
as
begin 
end







