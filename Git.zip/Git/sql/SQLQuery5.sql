select * from stock
truncate table stock
insert into stock values('Grapes',20),('Mango',30),('Apple',50)

create table rem_stock(
	id int constraint PK_rem_id primary key identity(1,1),
	p_id int constraint FK_rem_id foreign key references stock(id),
	rem_qty int
)
drop table rem_stock
select * from rem_stock
alter trigger updstock
on stock
for update
as
begin
	declare @id int, @qty int
	declare @oldqty int , @newqty int
	select * into #tempTable from inserted
	while(exists(select id from #tempTable))
	begin
		select top 1 @id = id, @newqty = quantity from #tempTable
		select @oldqty = quantity from deleted where id = @id
		
		if(@oldqty>=@newqty)
		begin
			insert into rem_stock values (@id,@newqty)
			update stock set quantity = @oldqty-@newqty where id=@id
			delete from #tempTable where id = @id
			print 'update done successfully...'
		end
		else 
		begin
			--update stock set quantity = @oldqty where id=@id
			delete from #tempTable where id = @id
			print 1/0
		end
		--else
		--begin
			--update stock set quantity = @oldqty where id=@id
			--delete from #tempTable where id = @id
			--print 'Invalid input...'
		--end
	end
end
truncate table rem_stock
update stock set quantity = 60 where id=3
select * from stock
select * from rem_stock
disable trigger all on stock

enable trigger all on stock

