select * from emp
insert into emp(name,email,salary) values('abc','abc@gmail.com',15000)
select *,coalesce (gender,'male') from emp

create table demo1(
id int,
date varchar(20)
)

insert into demo1 values(2,'2022/02/04'),(3,'22/02/2003')

select *,cast(date as varchar(20)) from demo1

select * from (select *,DENSE_RANK() over (order by salary desc) sal from emp) a where sal<10
select * from emp



