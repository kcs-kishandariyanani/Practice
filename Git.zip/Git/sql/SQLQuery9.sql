use AdventureWorks2014

select datepart(YYYY, soh.DueDate) as [Calendar Year], st.[Group] as [Sales Territory Group],
sum(soh.TotalDue) as [Sales Amount], pc.Name as Category
from Sales.SalesOrderHeader as soh
inner join Sales.SalesTerritory as st on soh.TerritoryID=st.TerritoryID
inner join Sales.SalesC as st on soh.TerritoryID=st.TerritoryID
inner join Sales.SalesOrderDetail as sod on soh.SalesOrderID= sod.SalesOrderID
inner join Production.ProductCostHistory as pch on sod.ProductID=pch.ProductID
cross join Production.ProductCategory as pc
group by DATEPART(yyyy,soh.DueDate),st.[Group],pc.Name
order by [Calendar Year]


select DATEPART(YYYY, soh.Duedate) as [calendar year], st.[Group] as [Sales Territory Group],
cr.Name as [Sales Territory Country], cr.Name as [Sales Territory Region],
SUM(soh.TotalDue) as [Sales Amount]
from Sales.SalesOrderHeader as soh
join Sales.SalesTerritory as st on soh.TerritoryID = st.TerritoryID
join Sales.SalesOrderDetail as sod on sod.SalesOrderID = sod.SalesOrderID
join Production.ProductCostHistory as pch on sod.ProductID = pch.ProductID
join Person.CountryRegion as cr on st.CountryRegionCode = cr.CountryRegionCode
group by DATEPART(YYYY, soh.DueDate), st.[Group], cr.Name
order by [calendar year]