use [Kishan.Dariyanani]
select * from emp where e_salary in (select e_salary from emp group by e_salary having count(*) >1)


select top 1 * from (select *,DENSE_RANK() over (order by e_salary desc) sal from emp ) a where sal=5

select * from (select * from emp where e_id <> 5) a where d_id=4

declare @ag int = (select avg(e_salary) from emp where d_id =4)
select * from emp where e_salary > @ag and d_id = 4
select * from emp where d_id=4

select avg(e_salary) from emp where d_id=1 

select avg(e_salary) from emp where d_id=4
select avg(e_salary) from emp where d_id is null
select avg(e_salary) from emp group by d_id
declare @ag1 int = (select avg(e_salary) from emp group by d_id) 
print @ag1
